import { GestureType, Landmark } from '../types';

// Configuration for gesture detection zones (0.0 to 1.0)
const ZONES = {
  TOP_EDGE: 0.2,      // Top 20% triggers Scroll Up
  BOTTOM_EDGE: 0.8,   // Bottom 20% triggers Scroll Down
  LEFT_EDGE: 0.15,    // Left 15% triggers Back
  RIGHT_EDGE: 0.85,   // Right 15% triggers Home
};

const SIMILARITY_THRESHOLD = 0.35; // Lower is stricter

// Helper: Normalize landmarks relative to wrist (0) to be position/scale invariant
export const normalizeLandmarks = (landmarks: Landmark[]): Landmark[] => {
  const wrist = landmarks[0];
  // Use distance from Wrist(0) to Middle Finger MCP(9) as scale reference
  const scaleRef = Math.sqrt(
    Math.pow(landmarks[9].x - wrist.x, 2) + 
    Math.pow(landmarks[9].y - wrist.y, 2)
  ) || 1;

  return landmarks.map(l => ({
    x: (l.x - wrist.x) / scaleRef,
    y: (l.y - wrist.y) / scaleRef,
    z: (l.z - wrist.z) / scaleRef
  }));
};

const calculateDifference = (current: Landmark[], template: Landmark[]): number => {
  if (current.length !== template.length) return Infinity;
  
  let totalDist = 0;
  for (let i = 0; i < current.length; i++) {
    const dx = current[i].x - template[i].x;
    const dy = current[i].y - template[i].y;
    const dz = current[i].z - template[i].z;
    totalDist += Math.sqrt(dx*dx + dy*dy + dz*dz);
  }
  return totalDist / current.length; // Average error
};

export const detectGesture = (landmarks: Landmark[], customTemplate: Landmark[] | null): GestureType => {
  const indexTip = landmarks[8];
  const { x, y } = indexTip;

  // 1. Check Custom Gesture (Highest Priority)
  if (customTemplate) {
    const normalizedCurrent = normalizeLandmarks(landmarks);
    const diff = calculateDifference(normalizedCurrent, customTemplate);
    
    if (diff < SIMILARITY_THRESHOLD) {
      return GestureType.CUSTOM;
    }
  }

  // 2. Navigation / Scroll Zones
  
  // Left Edge -> Back
  if (x < ZONES.LEFT_EDGE) {
    return GestureType.GO_BACK;
  }
  
  // Right Edge -> Home
  if (x > ZONES.RIGHT_EDGE) {
    return GestureType.GO_HOME;
  }

  // Top Edge -> Scroll Up
  if (y < ZONES.TOP_EDGE) {
    return GestureType.SCROLL_UP;
  }

  // Bottom Edge -> Scroll Down
  if (y > ZONES.BOTTOM_EDGE) {
    return GestureType.SCROLL_DOWN;
  }

  return GestureType.NONE;
};