import React, { useState } from 'react';
import { Camera, ShieldCheck, ChevronRight, AlertCircle } from 'lucide-react';

interface PermissionScreenProps {
  onPermissionGranted: () => void;
}

const PermissionScreen: React.FC<PermissionScreenProps> = ({ onPermissionGranted }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const requestPermission = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      
      // If successful, stop the tracks immediately (we just wanted the permission)
      // The actual video stream will be started by the GestureController
      stream.getTracks().forEach(track => track.stop());
      
      // Proceed to app
      onPermissionGranted();
    } catch (err) {
      console.error(err);
      setError("Camera permission was denied. Please allow camera access in your browser settings/address bar to use GestureOS.");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none z-0 opacity-20">
        <div className="absolute top-1/2 left-1/2 w-[600px] h-[600px] bg-blue-600/30 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />
      </div>

      <div className="max-w-md w-full bg-slate-800/50 p-8 rounded-3xl border border-slate-700 backdrop-blur-xl shadow-2xl space-y-8 text-center relative z-10">
        
        {/* Header */}
        <div className="space-y-4">
          <div className="w-20 h-20 bg-blue-500/20 rounded-3xl flex items-center justify-center mx-auto border border-blue-500/30 shadow-lg shadow-blue-500/10">
            <ShieldCheck size={40} className="text-blue-400" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
            Welcome to GestureOS
          </h1>
          <p className="text-slate-400 text-sm leading-relaxed">
            Experience touchless control. This app runs a local background service to detect your hand gestures in real-time.
          </p>
        </div>

        {/* Info Cards */}
        <div className="space-y-4 text-left">
          <div className="bg-slate-900/60 p-4 rounded-xl flex items-start gap-4 border border-slate-700/50">
            <Camera className="text-emerald-400 mt-1 shrink-0" size={20} />
            <div>
              <h3 className="font-semibold text-slate-200 text-sm">Camera Permission Required</h3>
              <p className="text-xs text-slate-500 mt-1">
                Required to track hand landmarks. 
              </p>
            </div>
          </div>
          
          <div className="bg-slate-900/60 p-4 rounded-xl flex items-start gap-4 border border-slate-700/50">
            <AlertCircle className="text-blue-400 mt-1 shrink-0" size={20} />
            <div>
              <h3 className="font-semibold text-slate-200 text-sm">Privacy First</h3>
              <p className="text-xs text-slate-500 mt-1">
                Processing happens 100% locally on your device. No video data is ever sent to a server.
              </p>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-500/20 border border-red-500/50 p-3 rounded-lg text-red-200 text-xs text-left animate-in fade-in slide-in-from-top-2">
            {error}
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={requestPermission}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg hover:shadow-emerald-500/25 flex items-center justify-center gap-2 group disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            "Initializing Service..."
          ) : (
            <>
              Start Background Service <ChevronRight className="group-hover:translate-x-1 transition-transform" />
            </>
          )}
        </button>

        <p className="text-[10px] text-slate-600">
          v1.0.0 • Powered by MediaPipe
        </p>
      </div>
    </div>
  );
};

export default PermissionScreen;