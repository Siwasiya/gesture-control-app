import React, { useEffect, useRef, useState, useCallback } from 'react';
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';
import { RefreshCw, XCircle } from 'lucide-react';
import { detectGesture, normalizeLandmarks } from '../services/gestureService';
import { GestureType, Landmark } from '../types';

interface GestureControllerProps {
  isEnabled: boolean;
  isTraining: boolean;
  customTemplate: Landmark[] | null;
  onGestureDetected: (gesture: GestureType) => void;
  onTrainingComplete: (template: Landmark[]) => void;
}

const GestureController: React.FC<GestureControllerProps> = ({ 
  isEnabled, 
  isTraining, 
  customTemplate,
  onGestureDetected, 
  onTrainingComplete 
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const handLandmarkerRef = useRef<HandLandmarker | null>(null);
  const requestRef = useRef<number>();

  // Initialize MediaPipe HandLandmarker
  useEffect(() => {
    const initMediaPipe = async () => {
      try {
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
        );
        
        handLandmarkerRef.current = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
            delegate: "GPU"
          },
          runningMode: "VIDEO",
          numHands: 1
        });
        
        setIsModelLoading(false);
      } catch (err) {
        console.error("Error loading MediaPipe:", err);
        setError("Failed to load AI Model");
        setIsModelLoading(false);
      }
    };

    initMediaPipe();
  }, []);

  // Initialize Camera (Starts automatically "in background")
  useEffect(() => {
    const startCamera = async () => {
      if (!videoRef.current) return;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, facingMode: "user" }
        });
        videoRef.current.srcObject = stream;
        videoRef.current.addEventListener('loadeddata', () => {
          setIsCameraReady(true);
        });
      } catch (err) {
        console.error("Camera error:", err);
        setError("Camera permission denied");
      }
    };

    if (!isCameraReady) {
      startCamera();
    }
  }, [isCameraReady]);

  // Processing Loop
  const predictWebcam = useCallback(() => {
    if (!videoRef.current || !canvasRef.current || !handLandmarkerRef.current || !isEnabled) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
    }

    let startTimeMs = performance.now();
    const results = handLandmarkerRef.current.detectForVideo(video, startTimeMs);

    ctx.save();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);

    if (results.landmarks && results.landmarks.length > 0) {
      const landmarks = results.landmarks[0];
      
      // Training Mode: Capture Frame
      if (isTraining) {
        const normalized = normalizeLandmarks(landmarks);
        onTrainingComplete(normalized);
        // Visual feedback for capture
        ctx.strokeStyle = "#FFFF00";
        ctx.lineWidth = 5;
        ctx.strokeRect(0, 0, canvas.width, canvas.height);
      }

      drawConnectors(ctx, landmarks);
      drawLandmarks(ctx, landmarks);

      const detected = detectGesture(landmarks, customTemplate);
      onGestureDetected(detected);

      // Highlight logic
      if (detected === GestureType.CUSTOM) {
        ctx.strokeStyle = "#00FFFF";
        ctx.lineWidth = 4;
        const boxSize = 100;
        // Draw box around hand center (approx landmark 9)
        const cx = landmarks[9].x * canvas.width;
        const cy = landmarks[9].y * canvas.height;
        ctx.strokeRect(cx - boxSize/2, cy - boxSize/2, boxSize, boxSize);
        
        ctx.scale(-1, 1);
        ctx.fillStyle = "#00FFFF";
        ctx.font = "bold 20px Arial";
        ctx.fillText("CUSTOM MATCH", -cx - 60, cy - 60);
        ctx.scale(-1, 1);
      } else {
        // Draw zones only if not a custom match
        drawZones(ctx, canvas.width, canvas.height);
      }

      // Draw Index Tip
      const indexTip = landmarks[8];
      ctx.beginPath();
      ctx.arc(indexTip.x * canvas.width, indexTip.y * canvas.height, 8, 0, 2 * Math.PI);
      ctx.fillStyle = "#00FF00";
      ctx.fill();

    } else {
      onGestureDetected(GestureType.NONE);
    }

    ctx.restore();
    requestRef.current = requestAnimationFrame(predictWebcam);
  }, [isEnabled, isTraining, customTemplate, onGestureDetected, onTrainingComplete]);

  useEffect(() => {
    if (isEnabled && isCameraReady && !isModelLoading) {
      requestRef.current = requestAnimationFrame(predictWebcam);
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isEnabled, isCameraReady, isModelLoading, predictWebcam]);

  const drawLandmarks = (ctx: CanvasRenderingContext2D, landmarks: Landmark[]) => {
    ctx.fillStyle = "#FF0000";
    for (const landmark of landmarks) {
      ctx.beginPath();
      ctx.arc(landmark.x * ctx.canvas.width, landmark.y * ctx.canvas.height, 3, 0, 2 * Math.PI);
      ctx.fill();
    }
  };

  const drawConnectors = (ctx: CanvasRenderingContext2D, landmarks: Landmark[]) => {
    ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
    ctx.lineWidth = 2;
    const connections = [[0,1],[1,2],[2,3],[3,4], [0,5],[5,6],[6,7],[7,8], [5,9],[9,10],[10,11],[11,12], [9,13],[13,14],[14,15],[15,16], [13,17],[17,18],[18,19],[19,20], [0,17]];
    ctx.beginPath();
    for (const [start, end] of connections) {
      const p1 = landmarks[start];
      const p2 = landmarks[end];
      ctx.moveTo(p1.x * ctx.canvas.width, p1.y * ctx.canvas.height);
      ctx.lineTo(p2.x * ctx.canvas.width, p2.y * ctx.canvas.height);
    }
    ctx.stroke();
  };

  const drawZones = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    ctx.globalAlpha = 0.15;
    ctx.fillStyle = "blue";
    ctx.fillRect(0, 0, w, h * 0.2); // Top
    ctx.fillRect(0, h * 0.8, w, h * 0.2); // Bottom
    ctx.fillStyle = "orange";
    ctx.fillRect(0, h * 0.2, w * 0.15, h * 0.6); // Left
    ctx.fillRect(w * 0.85, h * 0.2, w * 0.15, h * 0.6); // Right
    ctx.globalAlpha = 1.0;
  };

  return (
    <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-black aspect-video w-full max-w-[480px] border border-gray-700">
      {isModelLoading && (
        <div className="absolute inset-0 flex items-center justify-center text-white z-50 bg-black/80">
          <div className="flex flex-col items-center gap-2">
            <RefreshCw className="animate-spin" />
            <span>Loading AI...</span>
          </div>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center text-red-500 z-50 bg-black/90">
          <span>{error}</span>
        </div>
      )}
      <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 w-full h-full object-cover transform -scale-x-100" />
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-cover" />
      
      {/* Overlay Status */}
      <div className="absolute top-4 right-4 flex gap-2">
        <div className="bg-black/60 backdrop-blur px-3 py-1 rounded-full text-xs font-mono text-green-400 border border-green-500/30 animate-pulse">
           ● LIVE
        </div>
      </div>
    </div>
  );
};

export default GestureController;