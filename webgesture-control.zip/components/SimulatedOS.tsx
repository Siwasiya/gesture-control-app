import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Home, Battery, Wifi, Signal, Flashlight } from 'lucide-react';
import { GestureType } from '../types';

interface SimulatedOSProps {
  activeGesture: GestureType;
}

const SimulatedOS: React.FC<SimulatedOSProps> = ({ activeGesture }) => {
  const [currentApp, setCurrentApp] = useState<'launcher' | 'feed'>('launcher');
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isFlashlightOn, setIsFlashlightOn] = useState(false);
  
  // Debounce ref for toggle
  const lastToggleTime = useRef(0);

  // Handle Navigation & Custom Actions
  useEffect(() => {
    const now = Date.now();
    
    if (activeGesture === GestureType.GO_HOME) {
      setCurrentApp('launcher');
    } else if (activeGesture === GestureType.GO_BACK) {
      if (currentApp !== 'launcher') {
        setCurrentApp('launcher');
      }
    } else if (activeGesture === GestureType.CUSTOM) {
      // Debounce the flashlight toggle (prevent rapid flickering)
      if (now - lastToggleTime.current > 1000) {
        setIsFlashlightOn(prev => !prev);
        lastToggleTime.current = now;
      }
    }
  }, [activeGesture, currentApp]);

  // Handle Scrolling
  useEffect(() => {
    let animationFrameId: number;
    const scrollLoop = () => {
      if (scrollContainerRef.current) {
        if (activeGesture === GestureType.SCROLL_UP) {
          scrollContainerRef.current.scrollTop -= 10;
        } else if (activeGesture === GestureType.SCROLL_DOWN) {
          scrollContainerRef.current.scrollTop += 10;
        }
      }
      animationFrameId = requestAnimationFrame(scrollLoop);
    };

    if (activeGesture === GestureType.SCROLL_UP || activeGesture === GestureType.SCROLL_DOWN) {
      scrollLoop();
    }
    return () => cancelAnimationFrame(animationFrameId);
  }, [activeGesture]);

  const renderLauncher = () => (
    <div className="grid grid-cols-4 gap-4 p-6 pt-12">
      {[...Array(11)].map((_, i) => (
        <div 
          key={i}
          onClick={() => setCurrentApp('feed')}
          className="aspect-square bg-blue-500 rounded-2xl flex items-center justify-center shadow-lg cursor-pointer hover:bg-blue-400 transition-colors"
        >
          <div className="w-8 h-8 bg-white/20 rounded-full" />
        </div>
      ))}
      {/* Flashlight App Indicator */}
      <div className={`aspect-square rounded-2xl flex items-center justify-center shadow-lg transition-colors ${isFlashlightOn ? 'bg-yellow-400 text-black' : 'bg-gray-700 text-white'}`}>
        <Flashlight size={24} className={isFlashlightOn ? 'fill-black' : ''} />
      </div>
    </div>
  );

  const renderFeed = () => (
    <div className="p-4 space-y-4 pt-4">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">News Feed</h2>
      {[...Array(10)].map((_, i) => (
        <div key={i} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
          <div className="h-32 bg-gray-200 rounded-lg mb-3"></div>
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="relative w-[360px] h-[700px] bg-gray-50 rounded-[3rem] border-8 border-gray-800 shadow-2xl overflow-hidden flex flex-col transition-shadow duration-500" 
         style={{ boxShadow: isFlashlightOn ? '0 0 100px rgba(255, 255, 0, 0.3)' : '' }}>
      
      {/* Flashlight Overlay Effect */}
      {isFlashlightOn && (
        <div className="absolute top-8 right-8 w-64 h-64 bg-yellow-400/20 rounded-full blur-[80px] pointer-events-none z-0 mix-blend-screen" />
      )}

      {/* Status Bar */}
      <div className="h-8 bg-black/90 flex items-center justify-between px-6 text-white text-xs z-20">
        <span>9:41</span>
        <div className="flex gap-2 items-center">
          {isFlashlightOn && <Flashlight size={10} className="text-yellow-400 fill-yellow-400 animate-pulse" />}
          <Signal size={14} />
          <Wifi size={14} />
          <Battery size={14} />
        </div>
      </div>

      <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-7 bg-black rounded-full z-30" />

      <div 
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto scroll-smooth no-scrollbar bg-gray-50 relative z-10"
      >
        {currentApp === 'launcher' && renderLauncher()}
        {currentApp === 'feed' && renderFeed()}
      </div>

      <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-32 h-1.5 bg-gray-300 rounded-full z-20 mb-2" />

      {activeGesture !== GestureType.NONE && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-40 bg-black/10 transition-opacity">
          <div className="bg-black/70 text-white px-4 py-2 rounded-full font-bold backdrop-blur-md">
            {activeGesture.replace('_', ' ')}
          </div>
        </div>
      )}
    </div>
  );
};

export default SimulatedOS;